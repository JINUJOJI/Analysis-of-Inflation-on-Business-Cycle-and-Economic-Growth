# DWDM Analysis of Inflation Project

> Converted from the uploaded Jupyter Notebook. Code cells, Markdown text, and available cell outputs are included below. Output images are saved in `assets/` and linked from this document.

## Cell 1 — Code

```python
from google.colab import files
uploaded = files.upload()
```

**Output**

```text
<IPython.core.display.HTML object>
```

<details>
<summary>HTML output (expand)</summary>

```html

     <input type="file" id="files-9ceabf36-8c04-4b5b-89f9-94d07b3e4595" name="files[]" multiple disabled
        style="border:none" />
     <output id="result-9ceabf36-8c04-4b5b-89f9-94d07b3e4595">
      Upload widget is only available when the cell has been executed in the
      current browser session. Please rerun this cell to enable.
      </output>
      <script>// Copyright 2017 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @fileoverview Helpers for google.colab Python module.
 */
(function(scope) {
function span(text, styleAttributes = {}) {
  const element = document.createElement('span');
  element.textContent = text;
  for (const key of Object.keys(styleAttributes)) {
    element.style[key] = styleAttributes[key];
  }
  return element;
}

// Max number of bytes which will be uploaded at a time.
const MAX_PAYLOAD_SIZE = 100 * 1024;

function _uploadFiles(inputId, outputId) {
  const steps = uploadFilesStep(inputId, outputId);
  const outputElement = document.getElementById(outputId);
  // Cache steps on the outputElement to make it available for the next call
  // to uploadFilesContinue from Python.
  outputElement.steps = steps;

  return _uploadFilesContinue(outputId);
}

// This is roughly an async generator (not supported in the browser yet),
// where there are multiple asynchronous steps and the Python side is going
// to poll for completion of each step.
// This uses a Promise to block the python side on completion of each step,
// then passes the result of the previous step as the input to the next step.
function _uploadFilesContinue(outputId) {
  const outputElement = document.getElementById(outputId);
  const steps = outputElement.steps;

  const next = steps.next(outputElement.lastPromiseValue);
  return Promise.resolve(next.value.promise).then((value) => {
    // Cache the last promise value to make it available to the next
    // step of the generator.
    outputElement.lastPromiseValue = value;
    return next.value.response;
  });
}

/**
 * Generator function which is called between each async step of the upload
 * process.
 * @param {string} inputId Element ID of the input file picker element.
 * @param {string} outputId Element ID of the output display.
 * @return {!Iterable<!Object>} Iterable of next steps.
 */
function* uploadFilesStep(inputId, outputId) {
  const inputElement = document.getElementById(inputId);
  inputElement.disabled = false;

  const outputElement = document.getElementById(outputId);
  outputElement.innerHTML = '';

  const pickedPromise = new Promise((resolve) => {
    inputElement.addEventListener('change', (e) => {
      resolve(e.target.files);
    });
  });

  const cancel = document.createElement('button');
  inputElement.parentElement.appendChild(cancel);
  cancel.textContent = 'Cancel upload';
  const cancelPromise = new Promise((resolve) => {
    cancel.onclick = () => {
      resolve(null);
    };
  });

  // Wait for the user to pick the files.
  const files = yield {
    promise: Promise.race([pickedPromise, cancelPromise]),
    response: {
      action: 'starting',
    }
  };

  cancel.remove();

  // Disable the input element since further picks are not allowed.
  inputElement.disabled = true;

  if (!files) {
    return {
      response: {
        action: 'complete',
      }
    };
  }

  for (const file of files) {
    const li = document.createElement('li');
    li.append(span(file.name, {fontWeight: 'bold'}));
    li.append(span(
        `(${file.type || 'n/a'}) - ${file.size} bytes, ` +
        `last modified: ${
            file.lastModifiedDate ? file.lastModifiedDate.toLocaleDateString() :
                                    'n/a'} - `));
    const percent = span('0% done');
    li.appendChild(percent);

    outputElement.appendChild(li);

    const fileDataPromise = new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        resolve(e.target.result);
      };
      reader.readAsArrayBuffer(file);
    });
    // Wait for the data to be ready.
    let fileData = yield {
      promise: fileDataPromise,
      response: {
        action: 'continue',
      }
    };

    // Use a chunked sending to avoid message size limits. See b/62115660.
    let position = 0;
    do {
      const length = Math.min(fileData.byteLength - position, MAX_PAYLOAD_SIZE);
      const chunk = new Uint8Array(fileData, position, length);
      position += length;

      const base64 = btoa(String.fromCharCode.apply(null, chunk));
      yield {
        response: {
          action: 'append',
          file: file.name,
          data: base64,
        },
      };

      let percentDone = fileData.byteLength === 0 ?
          100 :
          Math.round((position / fileData.byteLength) * 100);
      percent.textContent = `${percentDone}% done`;

    } while (position < fileData.byteLength);
  }

  // All done.
  yield {
    response: {
      action: 'complete',
    }
  };
}

scope.google = scope.google || {};
scope.google.colab = scope.google.colab || {};
scope.google.colab._files = {
  _uploadFiles,
  _uploadFilesContinue,
};
})(self);
</script>
```

</details>

```text
Saving final_cleaned_economic_cpi_data.csv to final_cleaned_economic_cpi_data (1).csv
```

## Cell 2 — Markdown

# LOAD THE **DATASETS**

## Cell 3 — Code

```python
import os
import pandas as pd

# See all uploaded files
print("Your uploaded files:")
files = os.listdir('/content')
for file in files:
    print(f" {file}")

# Tell me the exact file names you see above
```

**Output**

```text
Your uploaded files:
 .config
 final_cleaned_economic_cpi_data.csv
 TerraSentinel_v4_Prediction_Pipeline.ipynb
 sample_data
```

## Cell 4 — Code

```python
# Load your datasets
df_economic = pd.read_csv('/content/economic_data.csv')
df_cpi = pd.read_csv('/content/cpi_data.csv')

# Check what's inside
print("     ECONOMIC DATA:    ")
print("\nShape:", df_economic.shape)
print("\nColumns:", df_economic.columns.tolist())
print("\nFirst 3 rows:")
print(df_economic.head(3))

print("\n   CPI DATA:   ")
print("\nShape:", df_cpi.shape)
print("\nColumns:", df_cpi.columns.tolist())
print("\nFirst 3 rows:")
print(df_cpi.head(3))
```

**Output**

**FileNotFoundError:** [Errno 2] No such file or directory: '/content/economic_data.csv'

```text
---------------------------------------------------------------------------
FileNotFoundError                         Traceback (most recent call last)
/tmp/ipykernel_2468/3418936458.py in <cell line: 0>()
      1 # Load your datasets
----> 2 df_economic = pd.read_csv('/content/economic_data.csv')
      3 df_cpi = pd.read_csv('/content/cpi_data.csv')
      4 
      5 # Check what's inside

/usr/local/lib/python3.13/dist-packages/pandas/io/parsers/readers.py in read_csv(filepath_or_buffer, sep, delimiter, header, names, index_col, usecols, dtype, engine, converters, true_values, false_values, skipinitialspace, skiprows, skipfooter, nrows, na_values, keep_default_na, na_filter, verbose, skip_blank_lines, parse_dates, infer_datetime_format, keep_date_col, date_parser, date_format, dayfirst, cache_dates, iterator, chunksize, compression, thousands, decimal, lineterminator, quotechar, quoting, doublequote, escapechar, comment, encoding, encoding_errors, dialect, on_bad_lines, delim_whitespace, low_memory, memory_map, float_precision, storage_options, dtype_backend)
   1024     kwds.update(kwds_defaults)
   1025 
-> 1026     return _read(filepath_or_buffer, kwds)
   1027 
   1028 

/usr/local/lib/python3.13/dist-packages/pandas/io/parsers/readers.py in _read(filepath_or_buffer, kwds)
    618 
    619     # Create the parser.
--> 620     parser = TextFileReader(filepath_or_buffer, **kwds)
    621 
    622     if chunksize or iterator:

/usr/local/lib/python3.13/dist-packages/pandas/io/parsers/readers.py in __init__(self, f, engine, **kwds)
   1618 
   1619         self.handles: IOHandles | None = None
-> 1620         self._engine = self._make_engine(f, self.engine)
   1621 
   1622     def close(self) -> None:

/usr/local/lib/python3.13/dist-packages/pandas/io/parsers/readers.py in _make_engine(self, f, engine)
   1878                 if "b" not in mode:
   1879                     mode += "b"
-> 1880             self.handles = get_handle(
   1881                 f,
   1882                 mode,

/usr/local/lib/python3.13/dist-packages/pandas/io/common.py in get_handle(path_or_buf, mode, encoding, compression, memory_map, is_text, errors, storage_options)
    871         if ioargs.encoding and "b" not in ioargs.mode:
    872             # Encoding
--> 873             handle = open(
    874                 handle,
    875                 ioargs.mode,

FileNotFoundError: [Errno 2] No such file or directory: '/content/economic_data.csv'
```

## Cell 5 — Markdown

# CLEANING THE DATA

## Cell 6 — Code

```python
# Clean Economic Data
print("CLEANING ECONOMIC DATA")
df_economic_clean = df_economic.drop(index=0)  # Remove first row
df_economic_clean = df_economic_clean.reset_index(drop=True)

# Clean CPI Data
print("CLEANING CPI DATA")
df_cpi_clean = df_cpi.drop(index=[0, 1])  # Remove first two messy rows
df_cpi_clean = df_cpi_clean.reset_index(drop=True)

# Check how many columns CPI data actually has
print(f"CPI data has {len(df_cpi_clean.columns)} columns")

# Set proper column names for CPI data (12 columns now)
new_cpi_columns = ['Year_AL', 'CPI_AL', 'Empty1', 'Year_IW', 'CPI_IW', 'CPI_IW_Food',
                   'Empty2', 'Year_New', 'Rural', 'Urban', 'Combined', 'Food_Beverages']
df_cpi_clean.columns = new_cpi_columns

print("\nCLEANED ECONOMIC DATA:\n")
print(df_economic_clean.head(2))
print("\n\n CLEANED CPI DATA:\n")
print(df_cpi_clean.head(2))
```

## Cell 7 — Markdown

# CLEANING-DATA TYPES FIXING

## Cell 8 — Code

```python
import numpy as np

# Fix Economic Data - remove commas and convert to numbers
print("FIXING ECONOMIC DATA TYPES...")
df_economic_clean = df_economic_clean.replace('-', np.nan)  # Replace dashes with NaN

# Convert all economic columns to numeric (except Year)
economic_columns = df_economic_clean.columns.drop('Year')
for col in economic_columns:
    df_economic_clean[col] = df_economic_clean[col].astype(str).str.replace(',', '')
    df_economic_clean[col] = pd.to_numeric(df_economic_clean[col], errors='coerce')

# Fix CPI Data - convert to numeric
print("FIXING CPI DATA TYPES...")
cpi_numeric_columns = ['CPI_AL', 'CPI_IW', 'CPI_IW_Food', 'Rural', 'Urban', 'Combined', 'Food_Beverages']
for col in cpi_numeric_columns:
    df_cpi_clean[col] = pd.to_numeric(df_cpi_clean[col], errors='coerce')

print("FIXED ECONOMIC DATA TYPES:")
print(df_economic_clean.dtypes)
print("\nFIXED CPI DATA TYPES:")
print(df_cpi_clean[['Year_AL', 'CPI_AL', 'Year_IW', 'CPI_IW']].dtypes)
```

## Cell 9 — Code

```python
print("CLEANED ECONOMIC DATASET")
print(f"Shape: {df_economic_clean.shape}")
print("\nFirst 5 rows:")
print(df_economic_clean.head())
print("\nYear range in economic data:")
print("Years available:")
print(df_economic_clean['Year'].unique())

print("\nCLEANED CPI DATASET\n")
print(f"Shape: {df_cpi_clean.shape}")
print("\nFirst 5 rows:")
print(df_cpi_clean.head())
print("\nYear range in CPI data (AL series):")
print("Years available in AL series:")
print(df_cpi_clean['Year_AL'].unique())
print("\nYear range in CPI data (New series):")
print("Years available in New series:")
print(df_cpi_clean['Year_New'].unique())
```

## Cell 10 — Code

```python
# Download cleaned economic data
df_economic_clean.to_csv('cleaned_economic_data.csv', index=False)

# Download cleaned CPI data
df_cpi_clean.to_csv('cleaned_cpi_data.csv', index=False)
```

## Cell 11 — Code

```python
# Standardize year formats for merging
df_economic_clean['Year'] = df_economic_clean['Year'].str.replace('-', '_')
df_cpi_clean['Year_AL'] = df_cpi_clean['Year_AL'].str.replace('-', '_')

# Merge datasets on Year column
merged_df = pd.merge(df_economic_clean, df_cpi_clean,
                    left_on='Year',
                    right_on='Year_AL',
                    how='inner')

print("MERGE RESULTS:")
print(f"Original Economic rows: {len(df_economic_clean)}")
print(f"Original CPI rows: {len(df_cpi_clean)}")
print(f"Merged dataset rows: {len(merged_df)}")
print(f"Merged dataset columns: {len(merged_df.columns)}")

print("\nFIRST 3 ROWS OF MERGED DATA:")
print(merged_df[['Year', 'Gross Domestic Product', 'CPI_AL', 'Combined']].head(3))

print("\nCOLUMNS IN MERGED DATA:")
print(merged_df.columns.tolist())

# Save merged dataset
merged_df.to_csv('merged_economic_cpi_data.csv', index=False)
print("\nMerged dataset saved as 'merged_economic_cpi_data.csv'")
```

## Cell 12 — Markdown

#CLEANING -HANDLING MISSING VALUES

## Cell 13 — Code

```python
print("CHECKING MISSING VALUES IN MERGED DATA:")
print(merged_df.isnull().sum())

print("\nDATA TYPES:")
print(merged_df.dtypes)

# Handle missing values
print("\nHANDLING MISSING VALUES...")

# Drop completely empty columns
merged_df_clean = merged_df.drop(columns=['Empty1', 'Empty2'])

# For Combined column (new CPI series) - it has data only for recent years
# We'll keep it as is for now since it's expected to have NaN for older years

print(f"After cleaning: {merged_df_clean.shape[1]} columns remaining")

print("\nFINAL MERGED DATASET INFO:")
print(merged_df_clean.info())

# Save the cleaned merged dataset
merged_df_clean.to_csv('final_merged_dataset.csv', index=False)
print("\nFinal merged dataset saved as 'final_merged_dataset.csv'")
```

## Cell 14 — Markdown

# MERGING DATASETS

## Cell 15 — Code

```python
# Remove rows where key economic data is missing (these are empty rows)
merged_df_clean = merged_df_clean.dropna(subset=['Gross Domestic Product', 'CPI_AL'])

# For missing Consumption of Fixed Capital and other economic metrics, use forward fill
economic_columns_to_fill = ['Consumption of Fixed Capital', 'Primary income receivable from ROW (net)',
                           'Gross Capital Formation', 'Net Capital Formation']
for col in economic_columns_to_fill:
    merged_df_clean[col] = merged_df_clean[col].fillna(method='ffill')

# Remove duplicate year columns and keep only essential ones
columns_to_keep = ['Year', 'Gross Domestic Product', 'Net Domestic Product', 'Gross National Income',
                  'Per Capita GDP (₹)', 'Per Capita GNI (₹)', 'CPI_AL', 'CPI_IW', 'CPI_IW_Food',
                  'Rural', 'Urban', 'Combined', 'Food_Beverages']

final_df = merged_df_clean[columns_to_keep]

print("FINAL CLEANED DATASET:")
print(f"Shape: {final_df.shape}")
print(f"Rows: {len(final_df)}")
print(f"Columns: {len(final_df.columns)}")

print("\nMISSING VALUES AFTER CLEANING:")
print(final_df.isnull().sum())

print("\nFIRST 5 ROWS:")
print(final_df.head())

# Save the final cleaned dataset
final_df.to_csv('final_cleaned_merged_data.csv', index=False)
print("\nFinal cleaned dataset saved as 'final_cleaned_merged_data.csv'")
```

## Cell 16 — Code

```python

# CPI_AL has NO missing values (complete 1970-2024)
# CPI_IW has only 2 missing rows

# Fill the 2 missing CPI_IW values using interpolation
analysis_df_smart = final_df[['Year', 'Gross Domestic Product', 'Net Domestic Product',
                             'Gross National Income', 'Per Capita GDP (₹)', 'Per Capita GNI (₹)',
                             'CPI_AL', 'CPI_IW', 'CPI_IW_Food']].copy()

# Interpolate the 2 missing CPI_IW values
analysis_df_smart['CPI_IW'] = analysis_df_smart['CPI_IW'].interpolate()
analysis_df_smart['CPI_IW_Food'] = analysis_df_smart['CPI_IW_Food'].interpolate()

print("SMART CLEANING - KEEP ALL YEARS:")
print(f"Shape: {analysis_df_smart.shape}")
print(f"Years: {len(analysis_df_smart)} (1970-2024)")
print("\nMISSING VALUES:")
print(analysis_df_smart.isnull().sum())
print("\nRECENT YEARS PRESERVED:")
print(analysis_df_smart[['Year', 'Gross Domestic Product', 'CPI_AL']].tail(5))
```

## Cell 17 — Code

```python
# Sort data chronologically (oldest to newest)
analysis_df_smart = analysis_df_smart.sort_values('Year').reset_index(drop=True)

print("DATA AFTER CHRONOLOGICAL SORTING:")
print(f"Shape: {analysis_df_smart.shape}")
print(f"Years: {len(analysis_df_smart)} (1970-2024)")

print("\nFIRST 5 ROWS (OLDEST):")
print(analysis_df_smart[['Year', 'Gross Domestic Product', 'CPI_AL']].head(5))

print("\nLAST 5 ROWS (NEWEST - 2020-2024):")
print(analysis_df_smart[['Year', 'Gross Domestic Product', 'CPI_AL']].tail(5))

print("\nCONFIRM RECENT YEARS PRESERVED:")
recent_years = ['2020_21', '2021_22', '2022_23', '2023_24', '2024_25']
recent_data = analysis_df_smart[analysis_df_smart['Year'].isin(recent_years)]
print(recent_data[['Year', 'Gross Domestic Product', 'CPI_AL']])

# Save the properly sorted dataset
analysis_df_smart.to_csv('analysis_ready_data_sorted.csv', index=False)
print("\nProperly sorted dataset saved!")
```

## Cell 18 — Code

```python
#Check all unique year values
print("ALL YEAR VALUES:")
print(analysis_df_smart['Year'].unique())

# Fix year formatting inconsistencies
analysis_df_smart['Year'] = analysis_df_smart['Year'].str.strip()  # Remove extra spaces

print("\nYEAR VALUES AFTER CLEANING:")
print(analysis_df_smart['Year'].unique())

print("\nCONFIRM RECENT YEARS AFTER FIX:")
recent_years = ['2020_21', '2021_22', '2022_23', '2023_24', '2024_25']
recent_data = analysis_df_smart[analysis_df_smart['Year'].isin(recent_years)]
print(recent_data[['Year', 'Gross Domestic Product', 'CPI_AL']])

print(f"\nRecent years found: {len(recent_data)}")
```

## Cell 19 — Code

```python
# Save the final cleaned dataset
analysis_df_smart.to_csv('final_cleaned_economic_cpi_data.csv', index=False)

print("FINAL CLEANED DATASET SAVED!")
print("File: 'final_cleaned_economic_cpi_data.csv'")
print(f"Shape: {analysis_df_smart.shape}")
print(f"Years: {analysis_df_smart['Year'].iloc[0]} to {analysis_df_smart['Year'].iloc[-1]}")
print(f"Columns: {list(analysis_df_smart.columns)}")
```

## Cell 20 — Markdown

# EDA

## Cell 21 — Code

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# Set up plotting style
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

print("\nEXPLORATORY DATA ANALYSIS - INFLATION & ECONOMIC GROWTH IN INDIA\n")


# Load your data
df = pd.read_csv('final_cleaned_economic_cpi_data.csv')

# Display basic information
print("18. DATASET OVERVIEW")
print(f"   Time Period: {df['Year'].iloc[0]} to {df['Year'].iloc[-1]}")
print(f"   Total Observations: {len(df)} years")
print(f"   Variables: {len(df.columns)}")
print(f"\nColumns: {df.columns.tolist()}")

print("\nFirst 5 rows:")
print(df.head())
```

**Output**

```text

EXPLORATORY DATA ANALYSIS - INFLATION & ECONOMIC GROWTH IN INDIA

18. DATASET OVERVIEW
   Time Period: 1970_71 to 2024_25
   Total Observations: 55 years
   Variables: 9

Columns: ['Year', 'Gross Domestic Product', 'Net Domestic Product', 'Gross National Income', 'Per Capita GDP (₹)', 'Per Capita GNI (₹)', 'CPI_AL', 'CPI_IW', 'CPI_IW_Food']

First 5 rows:
      Year  Gross Domestic Product  Net Domestic Product  \
0  1970_71               1089226.0             1018642.0   
1  1971_72               1107121.0             1033580.0   
2  1972_73               1100995.0             1024654.0   
3  1973_74               1137279.0             1057768.0   
4  1974_75               1150759.0             1066679.0   

   Gross National Income  Per Capita GDP (₹)  Per Capita GNI (₹)  CPI_AL  \
0              1082340.0             20134.0             20006.0   194.0   
1              1100363.0             19984.0             19862.0   196.0   
2              1094795.0             19418.0             19309.0   217.0   
3              1131633.0             19608.0             19511.0   263.0   
4              1146339.0             19406.0             19331.0   354.0   

   CPI_IW  CPI_IW_Food  
0   186.0        202.0  
1   192.0        205.0  
2   207.0        223.0  
3   250.0        279.0  
4   317.0        358.0
```

## Cell 22 — Code

```python
print("\n2. CALCULATING DERIVED VARIABLES\n")


# Calculate growth rates for all economic indicators
df['GDP_Growth_Rate'] = df['Gross Domestic Product'].pct_change() * 100
df['NDP_Growth_Rate'] = df['Net Domestic Product'].pct_change() * 100
df['GNI_Growth_Rate'] = df['Gross National Income'].pct_change() * 100
df['Per_Capita_GDP_Growth'] = df['Per Capita GDP (₹)'].pct_change() * 100

# Calculate inflation rates from different CPI measures
df['Inflation_AL'] = df['CPI_AL'].pct_change() * 100  # Agricultural Labourers
df['Inflation_IW'] = df['CPI_IW'].pct_change() * 100  # Industrial Workers
df['Inflation_Food'] = df['CPI_IW_Food'].pct_change() * 100  # Food Inflation

print("Growth rates calculated for all economic indicators")
print("Inflation rates calculated from different CPI measures")

# Display the new variables
print(f"\nNew variables created:")
new_vars = ['GDP_Growth_Rate', 'NDP_Growth_Rate', 'GNI_Growth_Rate', 'Per_Capita_GDP_Growth',
           'Inflation_AL', 'Inflation_IW', 'Inflation_Food']
print(new_vars)

print(f"\nFirst 5 rows with new variables:")
display_cols = ['Year', 'GDP_Growth_Rate', 'Inflation_AL', 'Inflation_IW', 'Inflation_Food']
print(df[display_cols].head(10))  # Show first 10 to see the pattern

print(f"\nBasic statistics of new variables:")
print(df[['GDP_Growth_Rate', 'Inflation_AL']].describe().round(2))
```

**Output**

```text

2. CALCULATING DERIVED VARIABLES

Growth rates calculated for all economic indicators
Inflation rates calculated from different CPI measures

New variables created:
['GDP_Growth_Rate', 'NDP_Growth_Rate', 'GNI_Growth_Rate', 'Per_Capita_GDP_Growth', 'Inflation_AL', 'Inflation_IW', 'Inflation_Food']

First 5 rows with new variables:
      Year  GDP_Growth_Rate  Inflation_AL  Inflation_IW  Inflation_Food
0  1970_71              NaN           NaN           NaN             NaN
1  1971_72         1.642910      1.030928      3.225806        1.485149
2  1972_73        -0.553327     10.714286      7.812500        8.780488
3  1973_74         3.295564     21.198157     20.772947       25.112108
4  1974_75         1.185285     34.600760     26.800000       28.315412
5  1975_76         9.149961     -3.954802     -1.261830       -4.469274
6  1976_77         1.663067    -13.823529     -3.833866       -7.309942
7  1977_78         7.254754     10.580205      7.641196        8.832808
8  1978_79         5.712550     -2.160494      2.160494        0.579710
9  1979_80        -5.238155      9.148265      8.761329        7.492795

Basic statistics of new variables:
       GDP_Growth_Rate  Inflation_AL
count            54.00         54.00
mean              5.47          5.55
std               3.19         13.82
min              -5.78        -81.23
25%               3.89          3.59
50%               6.10          6.73
75%               7.65         10.44
max               9.69         34.60
```

## Cell 23 — Markdown

# EDA-UNIVARIATE ANALYSIS

## Cell 24 — Code

```python
print("\n3. UNIVARIATE ANALYSIS - DISTRIBUTIONS\n")

# Create summary statistics for all variables
growth_vars = ['GDP_Growth_Rate', 'NDP_Growth_Rate', 'GNI_Growth_Rate', 'Per_Capita_GDP_Growth']
inflation_vars = ['Inflation_AL', 'Inflation_IW', 'Inflation_Food']

print("Descriptive Statistics - Growth Variables:")
print(df[growth_vars].describe().round(2))

print("\nDescriptive Statistics - Inflation Variables:")
print(df[inflation_vars].describe().round(2))

# Check for any extreme outliers
print(f"\nEXTREME VALUES CHECK:")
print(f"Minimum Inflation_AL: {df['Inflation_AL'].min():.2f}% (Year: {df.loc[df['Inflation_AL'].idxmin(), 'Year']})")
print(f"Maximum Inflation_AL: {df['Inflation_AL'].max():.2f}% (Year: {df.loc[df['Inflation_AL'].idxmax(), 'Year']})")
print(f"Minimum GDP Growth: {df['GDP_Growth_Rate'].min():.2f}% (Year: {df.loc[df['GDP_Growth_Rate'].idxmin(), 'Year']})")
print(f"Maximum GDP Growth: {df['GDP_Growth_Rate'].max():.2f}% (Year: {df.loc[df['GDP_Growth_Rate'].idxmax(), 'Year']})")

# Plot distributions
fig, axes = plt.subplots(2, 2, figsize=(15, 10))
fig.suptitle('Distribution of Key Economic Indicators', fontsize=16, fontweight='bold')

# GDP Growth Distribution
axes[0,0].hist(df['GDP_Growth_Rate'].dropna(), bins=12, alpha=0.7, color='skyblue', edgecolor='black')
axes[0,0].axvline(df['GDP_Growth_Rate'].mean(), color='red', linestyle='--', label=f'Mean: {df["GDP_Growth_Rate"].mean():.2f}%')
axes[0,0].set_title('GDP Growth Rate Distribution')
axes[0,0].set_xlabel('Growth Rate (%)')
axes[0,0].set_ylabel('Frequency')
axes[0,0].legend()
axes[0,0].grid(True, alpha=0.3)

# Inflation Distribution (Agricultural Labourers)
axes[0,1].hist(df['Inflation_AL'].dropna(), bins=15, alpha=0.7, color='lightcoral', edgecolor='black')
axes[0,1].axvline(df['Inflation_AL'].mean(), color='red', linestyle='--', label=f'Mean: {df["Inflation_AL"].mean():.2f}%')
axes[0,1].set_title('Inflation Rate Distribution (Agricultural Labourers)')
axes[0,1].set_xlabel('Inflation Rate (%)')
axes[0,1].set_ylabel('Frequency')
axes[0,1].legend()
axes[0,1].grid(True, alpha=0.3)

# Per Capita GDP Growth
axes[1,0].hist(df['Per_Capita_GDP_Growth'].dropna(), bins=12, alpha=0.7, color='lightgreen', edgecolor='black')
axes[1,0].axvline(df['Per_Capita_GDP_Growth'].mean(), color='red', linestyle='--', label=f'Mean: {df["Per_Capita_GDP_Growth"].mean():.2f}%')
axes[1,0].set_title('Per Capita GDP Growth Distribution')
axes[1,0].set_xlabel('Growth Rate (%)')
axes[1,0].set_ylabel('Frequency')
axes[1,0].legend()
axes[1,0].grid(True, alpha=0.3)

# Food Inflation
axes[1,1].hist(df['Inflation_Food'].dropna(), bins=15, alpha=0.7, color='orange', edgecolor='black')
axes[1,1].axvline(df['Inflation_Food'].mean(), color='red', linestyle='--', label=f'Mean: {df["Inflation_Food"].mean():.2f}%')
axes[1,1].set_title('Food Inflation Distribution')
axes[1,1].set_xlabel('Inflation Rate (%)')
axes[1,1].set_ylabel('Frequency')
axes[1,1].legend()
axes[1,1].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

print("Distribution plots completed!")
```

**Output**

```text

3. UNIVARIATE ANALYSIS - DISTRIBUTIONS

Descriptive Statistics - Growth Variables:
       GDP_Growth_Rate  NDP_Growth_Rate  GNI_Growth_Rate  \
count            54.00            54.00            54.00   
mean              5.47             5.34             5.45   
std               3.19             3.45             3.21   
min              -5.78            -7.35            -6.25   
25%               3.89             3.67             3.94   
50%               6.10             6.09             6.06   
75%               7.65             7.71             7.80   
max               9.69            10.15             9.89   

       Per_Capita_GDP_Growth  
count                  54.00  
mean                    3.62  
std                     3.32  
min                    -7.52  
25%                     2.14  
50%                     4.15  
75%                     6.22  
max                     8.63  

Descriptive Statistics - Inflation Variables:
       Inflation_AL  Inflation_IW  Inflation_Food
count         54.00         54.00           54.00
mean           5.55          3.50            3.58
std           13.82         17.72           17.73
min          -81.23        -73.79          -79.00
25%            3.59          4.12            2.26
50%            6.73          7.57            7.11
75%           10.44          9.72           10.75
max           34.60         26.80           28.32

EXTREME VALUES CHECK:
Minimum Inflation_AL: -81.23% (Year: 1995_96)
Maximum Inflation_AL: 34.60% (Year: 1974_75)
Minimum GDP Growth: -5.78% (Year: 2020_21)
Maximum GDP Growth: 9.69% (Year: 2021_22)
```

![Output image 1](assets/output_cell_24_02_01.png)

```text
<Figure size 1500x1000 with 4 Axes>
```

```text
Distribution plots completed!
```

## Cell 25 — Markdown

# EDA-TIME SERIES ANALYSIS

## Cell 26 — Code

```python
print("\n4. DATA CLEANING & TIME SERIES ANALYSIS\n")


# Let's investigate the 1995_96 anomaly
print("INVESTIGATING THE 1995_96 INFLATION ANOMALY:")
anomaly_year = df[df['Year'] == '1995_96']
print(f"1995_96 data:")
print(f"  CPI_AL: {anomaly_year['CPI_AL'].values[0]}")
print(f"  Previous year CPI_AL: {df[df['Year'] == '1994_95']['CPI_AL'].values[0]}")
print(f"  Calculated Inflation: {anomaly_year['Inflation_AL'].values[0]:.2f}%")

# Solution: We'll handle this by using a rolling approach or excluding extreme outliers
# For now, let's create a cleaned version for analysis
df_clean = df.copy()

# Remove the first row (NaN) and extreme outliers for better visualization
df_clean = df_clean[df_clean['Year'] != '1970_71']  # Remove first year with NaN
df_clean = df_clean[df_clean['Inflation_AL'] > -50]  # Remove extreme negative outlier

print(f"\nData after cleaning:")
print(f"Original rows: {len(df)}, Cleaned rows: {len(df_clean)}")

# Now create proper time series plots
print("\nCREATING TIME SERIES VISUALIZATIONS...")

# Create year numbers for better plotting
df_clean['Year_Num'] = df_clean['Year'].str.split('_').str[0].astype(int)

fig, axes = plt.subplots(2, 2, figsize=(16, 10))
fig.suptitle('Economic Trends Over Time (1971-2025)', fontsize=16, fontweight='bold')

# Plot 1: GDP Growth vs Inflation
axes[0,0].plot(df_clean['Year_Num'], df_clean['GDP_Growth_Rate'],
               marker='o', linewidth=2, label='GDP Growth', color='blue')
axes[0,0].plot(df_clean['Year_Num'], df_clean['Inflation_AL'],
               marker='s', linewidth=2, label='Inflation (AL)', color='red', alpha=0.7)
axes[0,0].set_title('GDP Growth vs Inflation Over Time')
axes[0,0].set_ylabel('Rate (%)')
axes[0,0].legend()
axes[0,0].grid(True, alpha=0.3)
axes[0,0].tick_params(axis='x', rotation=45)

# Plot 2: Different Inflation Measures Comparison
axes[0,1].plot(df_clean['Year_Num'], df_clean['Inflation_AL'],
               marker='o', linewidth=2, label='Agricultural Labourers')
axes[0,1].plot(df_clean['Year_Num'], df_clean['Inflation_IW'],
               marker='s', linewidth=2, label='Industrial Workers')
axes[0,1].plot(df_clean['Year_Num'], df_clean['Inflation_Food'],
               marker='^', linewidth=2, label='Food Inflation')
axes[0,1].set_title('Comparison of Different Inflation Measures')
axes[0,1].set_ylabel('Inflation Rate (%)')
axes[0,1].legend()
axes[0,1].grid(True, alpha=0.3)
axes[0,1].tick_params(axis='x', rotation=45)

# Plot 3: Absolute GDP Trend
axes[1,0].plot(df_clean['Year_Num'], df_clean['Gross Domestic Product']/1e6,
               marker='o', linewidth=2, color='green')
axes[1,0].set_title('Absolute GDP Trend (Millions ₹)')
axes[1,0].set_ylabel('GDP (Millions ₹)')
axes[1,0].set_xlabel('Year')
axes[1,0].grid(True, alpha=0.3)
axes[1,0].tick_params(axis='x', rotation=45)

# Plot 4: Per Capita GDP Trend
axes[1,1].plot(df_clean['Year_Num'], df_clean['Per Capita GDP (₹)']/1000,
               marker='s', linewidth=2, color='purple')
axes[1,1].set_title('Per Capita GDP Trend (000s ₹)')
axes[1,1].set_ylabel('Per Capita GDP (000s ₹)')
axes[1,1].set_xlabel('Year')
axes[1,1].grid(True, alpha=0.3)
axes[1,1].tick_params(axis='x', rotation=45)

plt.tight_layout()
plt.show()

print("Time series visualizations completed!")
print(f"Data cleaned: Removed extreme outlier from 1995_96")
```

**Output**

```text

4. DATA CLEANING & TIME SERIES ANALYSIS

INVESTIGATING THE 1995_96 INFLATION ANOMALY:
1995_96 data:
  CPI_AL: 234.0
  Previous year CPI_AL: 1247.0
  Calculated Inflation: -81.23%

Data after cleaning:
Original rows: 55, Cleaned rows: 53

CREATING TIME SERIES VISUALIZATIONS...
```

![Output image 2](assets/output_cell_26_02_01.png)

```text
<Figure size 1600x1000 with 4 Axes>
```

```text
Time series visualizations completed!
Data cleaned: Removed extreme outlier from 1995_96
```

## Cell 27 — Markdown

# EDA-CORRELATION ANALYSIS

## Cell 28 — Code

```python
print("\n5. CORRELATION ANALYSIS\n")
# Calculate correlations between growth and different inflation measures
correlation_vars = ['GDP_Growth_Rate', 'Inflation_AL', 'Inflation_IW', 'Inflation_Food',
                   'Per_Capita_GDP_Growth']
corr_matrix = df_clean[correlation_vars].corr()

print("Correlation Matrix (Growth vs Inflation):")
print(corr_matrix.round(3))

print("\nKEY CORRELATIONS:")
print(f"GDP Growth vs Inflation (Agricultural Labourers): {corr_matrix.loc['GDP_Growth_Rate', 'Inflation_AL']:.3f}")
print(f"GDP Growth vs Inflation (Industrial Workers): {corr_matrix.loc['GDP_Growth_Rate', 'Inflation_IW']:.3f}")
print(f"GDP Growth vs Food Inflation: {corr_matrix.loc['GDP_Growth_Rate', 'Inflation_Food']:.3f}")

# Visualize correlation matrix
plt.figure(figsize=(10, 8))
sns.heatmap(corr_matrix, annot=True, cmap='RdBu_r', center=0, square=True,
            linewidths=0.5, fmt='.3f', cbar_kws={'shrink': 0.8})
plt.title('Correlation Matrix: Economic Growth vs Inflation Measures', fontweight='bold', pad=20)
plt.tight_layout()
plt.show()

# Scatter plots to visualize relationships
fig, axes = plt.subplots(2, 2, figsize=(15, 12))
fig.suptitle('Relationship Between GDP Growth and Different Inflation Measures', fontsize=16, fontweight='bold')

inflation_measures = ['Inflation_AL', 'Inflation_IW', 'Inflation_Food']
titles = ['Agricultural Labourers CPI', 'Industrial Workers CPI', 'Food Inflation']

for i, (infl_measure, title) in enumerate(zip(inflation_measures, titles)):
    row, col = i // 2, i % 2
    correlation = df_clean['GDP_Growth_Rate'].corr(df_clean[infl_measure])

    axes[row, col].scatter(df_clean[infl_measure], df_clean['GDP_Growth_Rate'],
                          alpha=0.7, s=60, color='blue')
    axes[row, col].set_xlabel(f'{title} Inflation Rate (%)')
    axes[row, col].set_ylabel('GDP Growth Rate (%)')
    axes[row, col].set_title(f'{title}\nCorrelation: {correlation:.3f}')
    axes[row, col].grid(True, alpha=0.3)

    # Add trend line
    z = np.polyfit(df_clean[infl_measure].dropna(), df_clean['GDP_Growth_Rate'].dropna(), 1)
    p = np.poly1d(z)
    axes[row, col].plot(df_clean[infl_measure], p(df_clean[infl_measure]), "r--", alpha=0.8, linewidth=2)

# Fourth subplot: Rolling correlation over time
window = 5  # 5-year rolling window
df_sorted = df_clean.sort_values('Year_Num')
df_sorted['Rolling_Corr'] = df_sorted['GDP_Growth_Rate'].rolling(window=window).corr(df_sorted['Inflation_AL'])

axes[1, 1].plot(df_sorted['Year_Num'], df_sorted['Rolling_Corr'], marker='o', linewidth=2, color='green')
axes[1, 1].axhline(y=0, color='black', linestyle='--', alpha=0.5)
axes[1, 1].set_xlabel('Year')
axes[1, 1].set_ylabel('Correlation Coefficient')
axes[1, 1].set_title(f'{window}-Year Rolling Correlation\nGDP Growth vs Inflation')
axes[1, 1].grid(True, alpha=0.3)
axes[1, 1].tick_params(axis='x', rotation=45)

plt.tight_layout()
plt.show()

print("Correlation analysis completed!")
```

**Output**

```text

5. CORRELATION ANALYSIS

Correlation Matrix (Growth vs Inflation):
                       GDP_Growth_Rate  Inflation_AL  Inflation_IW  \
GDP_Growth_Rate                  1.000        -0.104        -0.158   
Inflation_AL                    -0.104         1.000         0.124   
Inflation_IW                    -0.158         0.124         1.000   
Inflation_Food                  -0.058         0.269         0.633   
Per_Capita_GDP_Growth            0.990        -0.113        -0.121   

                       Inflation_Food  Per_Capita_GDP_Growth  
GDP_Growth_Rate                -0.058                  0.990  
Inflation_AL                    0.269                 -0.113  
Inflation_IW                    0.633                 -0.121  
Inflation_Food                  1.000                 -0.024  
Per_Capita_GDP_Growth          -0.024                  1.000  

KEY CORRELATIONS:
GDP Growth vs Inflation (Agricultural Labourers): -0.104
GDP Growth vs Inflation (Industrial Workers): -0.158
GDP Growth vs Food Inflation: -0.058
```

![Output image 3](assets/output_cell_28_02_01.png)

```text
<Figure size 1000x800 with 2 Axes>
```

![Output image 4](assets/output_cell_28_03_01.png)

```text
<Figure size 1500x1200 with 4 Axes>
```

```text
Correlation analysis completed!
```

## Cell 29 — Markdown

# EDA-BUSINESS CYCLE AND STRUCTURAL ANALYSIS

## Cell 30 — Code

```python
print("\n6. BUSINESS CYCLE & STRUCTURAL ANALYSIS\n")
# Identify business cycle phases based on GDP growth
gdp_growth = df_clean['GDP_Growth_Rate']
growth_mean = gdp_growth.mean()
growth_std = gdp_growth.std()

print(f"GDP Growth Statistics:")
print(f"  Mean: {growth_mean:.2f}%")
print(f"  Standard Deviation: {growth_std:.2f}%")

# Define business cycle phases
df_clean['Business_Cycle'] = 'Moderate Growth'
df_clean.loc[df_clean['GDP_Growth_Rate'] > growth_mean + growth_std/2, 'Business_Cycle'] = 'Boom'
df_clean.loc[df_clean['GDP_Growth_Rate'] < growth_mean - growth_std/2, 'Business_Cycle'] = 'Recession/Slowdown'

print("\nBusiness Cycle Distribution:")
cycle_counts = df_clean['Business_Cycle'].value_counts()
print(cycle_counts)

# Analyze inflation in different business cycle phases
print("\nAverage Indicators by Business Cycle Phase:")
cycle_analysis = df_clean.groupby('Business_Cycle')[['GDP_Growth_Rate', 'Inflation_AL', 'Inflation_IW', 'Inflation_Food']].mean()
print(cycle_analysis.round(2))

# Structural breaks analysis (1991 Economic Reforms)
df_clean['Post_1991'] = df_clean['Year_Num'] >= 1991

pre_1991 = df_clean[df_clean['Year_Num'] < 1991]
post_1991 = df_clean[df_clean['Year_Num'] >= 1991]

print(f"\nSTRUCTURAL BREAK ANALYSIS (1991 Economic Reforms)")
print(f"Pre-1991 (1971-1990): {len(pre_1991)} years")
print(f"  Avg GDP Growth: {pre_1991['GDP_Growth_Rate'].mean():.2f}%")
print(f"  Avg Inflation (AL): {pre_1991['Inflation_AL'].mean():.2f}%")
print(f"  Avg Inflation (IW): {pre_1991['Inflation_IW'].mean():.2f}%")

print(f"\nPost-1991 (1991-2025): {len(post_1991)} years")
print(f"  Avg GDP Growth: {post_1991['GDP_Growth_Rate'].mean():.2f}%")
print(f"  Avg Inflation (AL): {post_1991['Inflation_AL'].mean():.2f}%")
print(f"  Avg Inflation (IW): {post_1991['Inflation_IW'].mean():.2f}%")

# Calculate growth-inflation correlation in different periods
corr_pre_1991 = pre_1991['GDP_Growth_Rate'].corr(pre_1991['Inflation_AL'])
corr_post_1991 = post_1991['GDP_Growth_Rate'].corr(post_1991['Inflation_AL'])

print(f"\nCorrelation Changes:")
print(f"  Pre-1991: GDP Growth vs Inflation = {corr_pre_1991:.3f}")
print(f"  Post-1991: GDP Growth vs Inflation = {corr_post_1991:.3f}")

# Visualize business cycle phases
plt.figure(figsize=(14, 8))

# Plot GDP growth with business cycle phases
colors = {'Boom': 'green', 'Moderate Growth': 'blue', 'Recession/Slowdown': 'red'}
for phase, color in colors.items():
    phase_data = df_clean[df_clean['Business_Cycle'] == phase]
    plt.scatter(phase_data['Year_Num'], phase_data['GDP_Growth_Rate'],
               color=color, label=phase, s=80, alpha=0.8)

plt.axhline(y=growth_mean, color='black', linestyle='--', alpha=0.7, label=f'Mean: {growth_mean:.2f}%')
plt.axhline(y=growth_mean + growth_std/2, color='gray', linestyle=':', alpha=0.5, label='±0.5 Std Dev')
plt.axhline(y=growth_mean - growth_std/2, color='gray', linestyle=':', alpha=0.5)

plt.xlabel('Year')
plt.ylabel('GDP Growth Rate (%)')
plt.title('Business Cycle Phases in Indian Economy (1971-2025)', fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

print("Business cycle analysis completed!")
```

**Output**

```text

6. BUSINESS CYCLE & STRUCTURAL ANALYSIS

GDP Growth Statistics:
  Mean: 5.43%
  Standard Deviation: 3.21%

Business Cycle Distribution:
Business_Cycle
Moderate Growth       22
Boom                  19
Recession/Slowdown    12
Name: count, dtype: int64

Average Indicators by Business Cycle Phase:
                    GDP_Growth_Rate  Inflation_AL  Inflation_IW  \
Business_Cycle                                                    
Boom                           8.19          6.68          2.02   
Moderate Growth                5.47          6.71          1.38   
Recession/Slowdown             0.96          8.86          8.47   

                    Inflation_Food  
Business_Cycle                      
Boom                          3.63  
Moderate Growth               4.16  
Recession/Slowdown            1.00  

STRUCTURAL BREAK ANALYSIS (1991 Economic Reforms)
Pre-1991 (1971-1990): 20 years
  Avg GDP Growth: 4.33%
  Avg Inflation (AL): 7.79%
  Avg Inflation (IW): 1.86%

Post-1991 (1991-2025): 33 years
  Avg GDP Growth: 6.09%
  Avg Inflation (AL): 6.83%
  Avg Inflation (IW): 4.04%

Correlation Changes:
  Pre-1991: GDP Growth vs Inflation = -0.086
  Post-1991: GDP Growth vs Inflation = -0.107
```

![Output image 5](assets/output_cell_30_02_01.png)

```text
<Figure size 1400x800 with 1 Axes>
```

```text
Business cycle analysis completed!
```

## Cell 31 — Markdown

# EDA-BOX PLOT ANALYSIS

## Cell 32 — Code

```python
print("\n8. BOX PLOT ANALYSIS - COMPARATIVE DISTRIBUTIONS\n")
# Create multiple box plots for comparative analysis
fig, axes = plt.subplots(2, 3, figsize=(18, 12))
fig.suptitle('Box Plot Analysis - Economic Indicators Across Categories', fontsize=16, fontweight='bold')

# 1. GDP Growth by Business Cycle
axes[0,0].boxplot([df_clean[df_clean['Business_Cycle'] == 'Boom']['GDP_Growth_Rate'],
                   df_clean[df_clean['Business_Cycle'] == 'Moderate Growth']['GDP_Growth_Rate'],
                   df_clean[df_clean['Business_Cycle'] == 'Recession/Slowdown']['GDP_Growth_Rate']],
                  labels=['Boom', 'Moderate', 'Recession'])
axes[0,0].set_title('GDP Growth by Business Cycle Phase')
axes[0,0].set_ylabel('GDP Growth Rate (%)')
axes[0,0].grid(True, alpha=0.3)

# 2. Inflation by Business Cycle
axes[0,1].boxplot([df_clean[df_clean['Business_Cycle'] == 'Boom']['Inflation_AL'],
                   df_clean[df_clean['Business_Cycle'] == 'Moderate Growth']['Inflation_AL'],
                   df_clean[df_clean['Business_Cycle'] == 'Recession/Slowdown']['Inflation_AL']],
                  labels=['Boom', 'Moderate', 'Recession'])
axes[0,1].set_title('Inflation (AL) by Business Cycle Phase')
axes[0,1].set_ylabel('Inflation Rate (%)')
axes[0,1].grid(True, alpha=0.3)

# 3. Different Inflation Measures Comparison
inflation_data = [df_clean['Inflation_AL'].dropna(),
                  df_clean['Inflation_IW'].dropna(),
                  df_clean['Inflation_Food'].dropna()]

axes[0,2].boxplot(inflation_data, labels=['Agri Labour', 'Ind Workers', 'Food'])
axes[0,2].set_title('Comparison of Different Inflation Measures')
axes[0,2].set_ylabel('Inflation Rate (%)')
axes[0,2].grid(True, alpha=0.3)

# 4. Pre vs Post 1991 Reforms - GDP Growth
pre_1991_growth = df_clean[df_clean['Post_1991'] == False]['GDP_Growth_Rate']
post_1991_growth = df_clean[df_clean['Post_1991'] == True]['GDP_Growth_Rate']

axes[1,0].boxplot([pre_1991_growth, post_1991_growth], labels=['Pre-1991', 'Post-1991'])
axes[1,0].set_title('GDP Growth: Pre vs Post 1991 Reforms')
axes[1,0].set_ylabel('GDP Growth Rate (%)')
axes[1,0].grid(True, alpha=0.3)

# 5. Pre vs Post 1991 Reforms - Inflation
pre_1991_infl = df_clean[df_clean['Post_1991'] == False]['Inflation_AL']
post_1991_infl = df_clean[df_clean['Post_1991'] == True]['Inflation_AL']

axes[1,1].boxplot([pre_1991_infl, post_1991_infl], labels=['Pre-1991', 'Post-1991'])
axes[1,1].set_title('Inflation: Pre vs Post 1991 Reforms')
axes[1,1].set_ylabel('Inflation Rate (%)')
axes[1,1].grid(True, alpha=0.3)

# 6. All Growth Measures Comparison
growth_data = [df_clean['GDP_Growth_Rate'].dropna(),
               df_clean['NDP_Growth_Rate'].dropna(),
               df_clean['GNI_Growth_Rate'].dropna(),
               df_clean['Per_Capita_GDP_Growth'].dropna()]

axes[1,2].boxplot(growth_data, labels=['GDP', 'NDP', 'GNI', 'Per Capita'])
axes[1,2].set_title('Comparison of Different Growth Measures')
axes[1,2].set_ylabel('Growth Rate (%)')
axes[1,2].grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

print("Box plots created successfully!")

# Statistical summary of box plot findings
print("\nBOX PLOT STATISTICAL SUMMARY")
print("1. GDP GROWTH BY BUSINESS CYCLE:")
for phase in ['Boom', 'Moderate Growth', 'Recession/Slowdown']:
    data = df_clean[df_clean['Business_Cycle'] == phase]['GDP_Growth_Rate']
    print(f"   {phase:15} | Median: {data.median():.2f}% | IQR: {data.quantile(0.75)-data.quantile(0.25):.2f}%")

print("\n2. INFLATION BY BUSINESS CYCLE:")
for phase in ['Boom', 'Moderate Growth', 'Recession/Slowdown']:
    data = df_clean[df_clean['Business_Cycle'] == phase]['Inflation_AL']
    print(f"   {phase:15} | Median: {data.median():.2f}% | IQR: {data.quantile(0.75)-data.quantile(0.25):.2f}%")

print("\n3. PRE vs POST 1991 REFORMS:")
print(f"   GDP Growth:")
print(f"     Pre-1991  | Median: {pre_1991_growth.median():.2f}% | Range: {pre_1991_growth.min():.2f}% to {pre_1991_growth.max():.2f}%")
print(f"     Post-1991 | Median: {post_1991_growth.median():.2f}% | Range: {post_1991_growth.min():.2f}% to {post_1991_growth.max():.2f}%")

print(f"\n   Inflation:")
print(f"     Pre-1991  | Median: {pre_1991_infl.median():.2f}% | Range: {pre_1991_infl.min():.2f}% to {pre_1991_infl.max():.2f}%")
print(f"     Post-1991 | Median: {post_1991_infl.median():.2f}% | Range: {post_1991_infl.min():.2f}% to {post_1991_infl.max():.2f}%")

# Outlier analysis
print("\n4. OUTLIER ANALYSIS:")
print("   Extreme values that might need special attention in modeling")

# Identify outliers using IQR method
def find_outliers_iqr(data):
    Q1 = data.quantile(0.25)
    Q3 = data.quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = data[(data < lower_bound) | (data > upper_bound)]
    return outliers

gdp_outliers = find_outliers_iqr(df_clean['GDP_Growth_Rate'])
infl_outliers = find_outliers_iqr(df_clean['Inflation_AL'])

print(f"   GDP Growth Outliers: {len(gdp_outliers)} values")
if len(gdp_outliers) > 0:
    for year, value in zip(df_clean.loc[gdp_outliers.index, 'Year'], gdp_outliers):
        print(f"     {year}: {value:.2f}%")

print(f"   Inflation Outliers: {len(infl_outliers)} values")
if len(infl_outliers) > 0:
    for year, value in zip(df_clean.loc[infl_outliers.index, 'Year'], infl_outliers):
        print(f"     {year}: {value:.2f}%")
```

**Output**

```text

8. BOX PLOT ANALYSIS - COMPARATIVE DISTRIBUTIONS
```

![Output image 6](assets/output_cell_32_02_01.png)

```text
<Figure size 1800x1200 with 6 Axes>
```

```text
Box plots created successfully!

BOX PLOT STATISTICAL SUMMARY
1. GDP GROWTH BY BUSINESS CYCLE:
   Boom            | Median: 7.92% | IQR: 1.04%
   Moderate Growth | Median: 5.51% | IQR: 1.55%
   Recession/Slowdown | Median: 1.65% | IQR: 2.69%

2. INFLATION BY BUSINESS CYCLE:
   Boom            | Median: 6.79% | IQR: 5.59%
   Moderate Growth | Median: 6.60% | IQR: 7.51%
   Recession/Slowdown | Median: 7.33% | IQR: 10.18%

3. PRE vs POST 1991 REFORMS:
   GDP Growth:
     Pre-1991  | Median: 5.02% | Range: -5.24% to 9.63%
     Post-1991 | Median: 6.66% | Range: -5.78% to 9.69%

   Inflation:
     Pre-1991  | Median: 8.32% | Range: -13.82% to 34.60%
     Post-1991 | Median: 6.67% | Range: -0.33% to 19.30%

4. OUTLIER ANALYSIS:
   Extreme values that might need special attention in modeling
   GDP Growth Outliers: 2 values
     1979_80: -5.24%
     2020_21: -5.78%
   Inflation Outliers: 3 values
     1973_74: 21.20%
     1974_75: 34.60%
     1976_77: -13.82%
```

## Cell 33 — Markdown

# Creating a baseline model

## Cell 34 — Code

```python
# Checks what variables are available
print("Available variables in your environment:")
print([var for var in dir() if not var.startswith('_')])
```

**Output**

```text
Available variables in your environment:
['In', 'Out', 'anomaly_year', 'axes', 'col', 'color', 'colors', 'corr_matrix', 'corr_post_1991', 'corr_pre_1991', 'correlation', 'correlation_vars', 'cycle_analysis', 'cycle_counts', 'data', 'df', 'df_clean', 'df_sorted', 'display_cols', 'exit', 'fig', 'file', 'files', 'find_outliers_iqr', 'gdp_growth', 'gdp_outliers', 'get_ipython', 'growth_data', 'growth_mean', 'growth_std', 'growth_vars', 'i', 'infl_measure', 'infl_outliers', 'inflation_data', 'inflation_measures', 'inflation_vars', 'new_vars', 'np', 'os', 'p', 'pd', 'phase', 'phase_data', 'plt', 'post_1991', 'post_1991_growth', 'post_1991_infl', 'pre_1991', 'pre_1991_growth', 'pre_1991_infl', 'quit', 'row', 'sns', 'stats', 'title', 'titles', 'uploaded', 'value', 'warnings', 'window', 'year', 'z']
```

## Cell 35 — Code

```python
import pandas as pd
import numpy as np
from statsmodels.tsa.stattools import adfuller
df = pd.read_csv('final_cleaned_economic_cpi_data.csv')
print("Dataset shape:", df.shape)
print("\nFirst 5 rows:")
print(df.head())
print("\nColumn names:")
print(df.columns.tolist())
```

**Output**

```text
Dataset shape: (55, 9)

First 5 rows:
      Year  Gross Domestic Product  Net Domestic Product  \
0  1970_71               1089226.0             1018642.0   
1  1971_72               1107121.0             1033580.0   
2  1972_73               1100995.0             1024654.0   
3  1973_74               1137279.0             1057768.0   
4  1974_75               1150759.0             1066679.0   

   Gross National Income  Per Capita GDP (₹)  Per Capita GNI (₹)  CPI_AL  \
0              1082340.0             20134.0             20006.0   194.0   
1              1100363.0             19984.0             19862.0   196.0   
2              1094795.0             19418.0             19309.0   217.0   
3              1131633.0             19608.0             19511.0   263.0   
4              1146339.0             19406.0             19331.0   354.0   

   CPI_IW  CPI_IW_Food  
0   186.0        202.0  
1   192.0        205.0  
2   207.0        223.0  
3   250.0        279.0  
4   317.0        358.0  

Column names:
['Year', 'Gross Domestic Product', 'Net Domestic Product', 'Gross National Income', 'Per Capita GDP (₹)', 'Per Capita GNI (₹)', 'CPI_AL', 'CPI_IW', 'CPI_IW_Food']
```

## Cell 36 — Markdown

# Testing stationarity

## Cell 37 — Code

```python
variables_to_test = ['Gross Domestic Product', 'Per Capita GDP (₹)', 'CPI_AL', 'CPI_IW']
print("STATIONARITY TEST RESULTS")
for var in variables_to_test:
    result = adfuller(df[var].dropna())
    print(f"{var}:")
    print(f"  ADF Statistic: {result[0]:.4f}")
    print(f"  p-value: {result[1]:.4f}")
    if result[1] < 0.05:
        print("\nSTATIONARY!!")
    else:
        print("\nNON-STATIONARY (needs differencing)")
```

**Output**

```text
STATIONARITY TEST RESULTS
Gross Domestic Product:
  ADF Statistic: 5.1099
  p-value: 1.0000

NON-STATIONARY (needs differencing)
Per Capita GDP (₹):
  ADF Statistic: 4.9211
  p-value: 1.0000

NON-STATIONARY (needs differencing)
CPI_AL:
  ADF Statistic: -1.2197
  p-value: 0.6651

NON-STATIONARY (needs differencing)
CPI_IW:
  ADF Statistic: -3.1248
  p-value: 0.0248

STATIONARY!!
```

## Cell 38 — Markdown

# VAR MODEL -creating stationary variables

## Cell 39 — Code

```python
df['GDP_Growth'] = df['Gross Domestic Product'].pct_change()
df['Inflation_AL'] = df['CPI_AL'].pct_change()
df_stationary = df[['GDP_Growth', 'Inflation_AL', 'CPI_IW']].dropna()
print("Stationary dataset for VAR modeling:")
print(df_stationary.head(10))
print(f"\nFinal dataset shape: {df_stationary.shape}")
print("\nSTATIONARITY CHECK OF GROWTH RATES")
result_gdp = adfuller(df_stationary['GDP_Growth'])
result_inf = adfuller(df_stationary['Inflation_AL'])
print(f"GDP Growth Rate: ADF={result_gdp[0]:.4f}, p-value={result_gdp[1]:.4f} :{'STATIONARY ' if result_gdp[1] < 0.05 else 'NON-STATIONARY'}")
print(f"Inflation Rate AL: ADF={result_inf[0]:.4f}, p-value={result_inf[1]:.4f} :{'STATIONARY ' if result_inf[1] < 0.05 else 'NON-STATIONARY'}")
```

**Output**

```text
Stationary dataset for VAR modeling:
    GDP_Growth  Inflation_AL  CPI_IW
1     0.016429      0.010309   192.0
2    -0.005533      0.107143   207.0
3     0.032956      0.211982   250.0
4     0.011853      0.346008   317.0
5     0.091500     -0.039548   313.0
6     0.016631     -0.138235   301.0
7     0.072548      0.105802   324.0
8     0.057126     -0.021605   331.0
9    -0.052382      0.091483   360.0
10    0.067358      0.141618   401.0

Final dataset shape: (54, 3)

STATIONARITY CHECK OF GROWTH RATES
GDP Growth Rate: ADF=-7.1239, p-value=0.0000 :STATIONARY 
Inflation Rate AL: ADF=-7.3461, p-value=0.0000 :STATIONARY
```

## Cell 40 — Markdown

# VAR MODEL-Building

## Cell 41 — Code

```python
from statsmodels.tsa.api import VAR
from statsmodels.tsa.stattools import grangercausalitytests
import matplotlib.pyplot as plt
var_data = df_stationary[['GDP_Growth', 'Inflation_AL', 'CPI_IW']]

model = VAR(var_data)
lag_results = model.select_order(maxlags=8)
print("\nOPTIMAL LAG SELECTION\n")

print("\n".join(
    line for line in str(lag_results.summary()).split("\n")
    if not line.strip().startswith("=")
))
optimal_lags = lag_results.selected_orders['aic']
print(f"\nOptimal lag length (AIC): {optimal_lags}")

var_model = model.fit(optimal_lags)
print("\nVAR MODEL SUMMARY\n")

print("\n".join(
    line for line in str(var_model.summary()).split("\n")
    if not line.strip().startswith("=")
))
```

**Output**

```text

OPTIMAL LAG SELECTION

 VAR Order Selection (* highlights the minimums) 
      AIC         BIC         FPE         HQIC   
-------------------------------------------------
0     -0.6838     -0.5646      0.5047     -0.6391
1      -1.880     -1.403*      0.1528     -1.702*
2      -1.848      -1.014      0.1586      -1.536
3      -1.605     -0.4122      0.2052      -1.158
4      -1.528     0.02271      0.2276     -0.9469
5      -1.319      0.5891      0.2928     -0.6043
6      -1.183       1.083      0.3586     -0.3340
7      -1.667      0.9564      0.2435     -0.6844
8     -2.330*      0.6518     0.1443*      -1.213
-------------------------------------------------

Optimal lag length (AIC): 8

VAR MODEL SUMMARY

  Summary of Regression Results   
Model:                         VAR
Method:                        OLS
Date:           Fri, 23, Oct, 2026
Time:                     06:06:16
--------------------------------------------------------------------
No. of Equations:         3.00000    BIC:                   0.651814
Nobs:                     46.0000    HQIC:                  -1.21279
Log likelihood:          -67.2312    FPE:                   0.144271
AIC:                     -2.32967    Det(Omega_mle):       0.0392353
--------------------------------------------------------------------
Results for equation GDP_Growth
                     coefficient       std. error           t-stat            prob
----------------------------------------------------------------------------------
const                  -0.052173         0.041449           -1.259           0.208
L1.GDP_Growth          -0.273701         0.180228           -1.519           0.129
L1.Inflation_AL        -0.033761         0.052990           -0.637           0.524
L1.CPI_IW               0.000130         0.000088            1.475           0.140
L2.GDP_Growth          -0.087666         0.170018           -0.516           0.606
L2.Inflation_AL        -0.058291         0.043540           -1.339           0.181
L2.CPI_IW              -0.000044         0.000154           -0.287           0.774
L3.GDP_Growth          -0.050859         0.172229           -0.295           0.768
L3.Inflation_AL        -0.068913         0.043100           -1.599           0.110
L3.CPI_IW               0.000084         0.000187            0.450           0.653
L4.GDP_Growth          -0.183242         0.169977           -1.078           0.281
L4.Inflation_AL        -0.118109         0.043420           -2.720           0.007
L4.CPI_IW              -0.000158         0.000208           -0.761           0.447
L5.GDP_Growth          -0.058613         0.229598           -0.255           0.799
L5.Inflation_AL        -0.050984         0.036048           -1.414           0.157
L5.CPI_IW               0.000094         0.000217            0.435           0.663
L6.GDP_Growth           0.348675         0.224530            1.553           0.120
L6.Inflation_AL         0.003568         0.034400            0.104           0.917
L6.CPI_IW              -0.000019         0.000210           -0.088           0.930
L7.GDP_Growth           0.604048         0.203814            2.964           0.003
L7.Inflation_AL         0.043940         0.034158            1.286           0.198
L7.CPI_IW               0.000057         0.000200            0.286           0.775
L8.GDP_Growth           0.667298         0.237819            2.806           0.005
L8.Inflation_AL        -0.005924         0.033565           -0.176           0.860
L8.CPI_IW               0.000074         0.000115            0.649           0.516

Results for equation Inflation_AL
                     coefficient       std. error           t-stat            prob
----------------------------------------------------------------------------------
const                  -0.103372         0.142281           -0.727           0.468
L1.GDP_Growth          -0.245378         0.618661           -0.397           0.692
L1.Inflation_AL        -0.370367         0.181897           -2.036           0.042
L1.CPI_IW               0.000085         0.000301            0.281           0.779
L2.GDP_Growth           0.791879         0.583613            1.357           0.175
L2.Inflation_AL         0.069047         0.149459            0.462           0.644
L2.CPI_IW               0.000102         0.000528            0.193           0.847
L3.GDP_Growth           0.169266         0.591201            0.286           0.775
L3.Inflation_AL         0.041770         0.147949            0.282           0.778
L3.CPI_IW              -0.000556         0.000642           -0.865           0.387
L4.GDP_Growth           0.644586         0.583473            1.105           0.269
L4.Inflation_AL        -0.031565         0.149045           -0.212           0.832
L4.CPI_IW               0.000812         0.000714            1.138           0.255
L5.GDP_Growth          -0.289295         0.788130           -0.367           0.714
L5.Inflation_AL         0.081513         0.123741            0.659           0.510
L5.CPI_IW              -0.000782         0.000744           -1.051           0.293
L6.GDP_Growth           0.352966         0.770732            0.458           0.647
L6.Inflation_AL         0.125143         0.118083            1.060           0.289
L6.CPI_IW               0.000978         0.000722            1.356           0.175
L7.GDP_Growth           0.091197         0.699625            0.130           0.896
L7.Inflation_AL         0.119626         0.117251            1.020           0.308
L7.CPI_IW               0.000554         0.000688            0.805           0.421
L8.GDP_Growth           1.033876         0.816352            1.266           0.205
L8.Inflation_AL         0.149428         0.115215            1.297           0.195
L8.CPI_IW              -0.001184         0.000393           -3.008           0.003

Results for equation CPI_IW
                     coefficient       std. error           t-stat            prob
----------------------------------------------------------------------------------
const                 342.486510        92.243407            3.713           0.000
L1.GDP_Growth          41.907744       401.088260            0.104           0.917
L1.Inflation_AL        20.833792       117.926702            0.177           0.860
L1.CPI_IW               1.330228         0.195462            6.806           0.000
L2.GDP_Growth         206.031800       378.366092            0.545           0.586
L2.Inflation_AL       124.625847        96.896744            1.286           0.198
L2.CPI_IW              -1.072995         0.342580           -3.132           0.002
L3.GDP_Growth         -66.162091       383.285652           -0.173           0.863
L3.Inflation_AL       150.413268        95.917479            1.568           0.117
L3.CPI_IW               0.794815         0.416512            1.908           0.056
L4.GDP_Growth        -157.024099       378.275471           -0.415           0.678
L4.Inflation_AL       114.129638        96.628285            1.181           0.238
L4.CPI_IW              -0.590907         0.462736           -1.277           0.202
L5.GDP_Growth        -434.862647       510.957502           -0.851           0.395
L5.Inflation_AL       -11.228215        80.223378           -0.140           0.889
L5.CPI_IW               0.345186         0.482483            0.715           0.474
L6.GDP_Growth        -664.947822       499.678520           -1.331           0.183
L6.Inflation_AL       -26.894794        76.554902           -0.351           0.725
L6.CPI_IW              -0.295613         0.467823           -0.632           0.527
L7.GDP_Growth       -1018.805133       453.578156           -2.246           0.025
L7.Inflation_AL       -67.264488        76.015748           -0.885           0.376
L7.CPI_IW               0.077838         0.446096            0.174           0.861
L8.GDP_Growth        -979.255969       529.254358           -1.850           0.064
L8.Inflation_AL       -93.351866        74.696079           -1.250           0.211
L8.CPI_IW              -0.145896         0.255065           -0.572           0.567

Correlation matrix of residuals
                GDP_Growth  Inflation_AL    CPI_IW
GDP_Growth        1.000000      0.045422  0.276924
Inflation_AL      0.045422      1.000000  0.043491
CPI_IW            0.276924      0.043491  1.000000
```

```text
/usr/local/lib/python3.13/dist-packages/statsmodels/tsa/base/tsa_model.py:480: ValueWarning: An unsupported index was provided. As a result, forecasts cannot be generated. To use the model for forecasting, use on the supported classes of index.
  self._init_dates(dates, freq)
```

## Cell 42 — Markdown

# VAR MODEL-GRANGER CAUSALITY **TEST**

## Cell 43 — Code

```python

print("\nGRANGER CAUSALITY TESTS - BIDIRECTIONAL ANALYSIS")

variable_pairs = [
    ('Inflation_AL', 'GDP_Growth'),
    ('GDP_Growth', 'Inflation_AL'),
    ('CPI_IW', 'GDP_Growth'),
    ('GDP_Growth', 'CPI_IW'),
    ('Inflation_AL', 'CPI_IW'),
    ('CPI_IW', 'Inflation_AL')
]

results = {}

for cause_var, effect_var in variable_pairs:
    print(f"\n{cause_var} → {effect_var}")
    try:
        gc_result = grangercausalitytests(var_data[[effect_var, cause_var]],
                                        maxlag=optimal_lags, verbose=False)
        p_values = [gc_result[i+1][0]['ssr_ftest'][1] for i in range(optimal_lags)]
        min_p_value = min(p_values)

        print(f"   p-values across lags: {[f'{p:.4f}' for p in p_values]}")
        print(f"   Minimum p-value: {min_p_value:.4f}")

        if min_p_value < 0.05:
            print(f" {cause_var} Granger-causes {effect_var} (p < 0.05)")
        else:
            print(f"No Granger causality from {cause_var} to {effect_var} (p ≥ 0.05)")

        results[f"{cause_var}_to_{effect_var}"] = min_p_value

    except Exception as e:
        print(f"Error testing {cause_var} → {effect_var}: {e}")
causal_relationships = []
for relationship, p_value in results.items():
    if p_value < 0.05:
        causal_relationships.append(relationship)

if causal_relationships:
    print("SIGNIFICANT CAUSAL RELATIONSHIPS FOUND:")
    for rel in causal_relationships:
        print(f"   - {rel.replace('_to_', ' → ')}")
else:
    print("NO significant Granger causality relationships found")

print(f"\nInterpretation:")
print("Granger causality means past values of X help predict current values of Y")
print("This indicates predictive relationship, not necessarily true causation")
```

**Output**

```text

GRANGER CAUSALITY TESTS - BIDIRECTIONAL ANALYSIS

Inflation_AL → GDP_Growth
Error testing Inflation_AL → GDP_Growth: grangercausalitytests() got an unexpected keyword argument 'verbose'

GDP_Growth → Inflation_AL
Error testing GDP_Growth → Inflation_AL: grangercausalitytests() got an unexpected keyword argument 'verbose'

CPI_IW → GDP_Growth
Error testing CPI_IW → GDP_Growth: grangercausalitytests() got an unexpected keyword argument 'verbose'

GDP_Growth → CPI_IW
Error testing GDP_Growth → CPI_IW: grangercausalitytests() got an unexpected keyword argument 'verbose'

Inflation_AL → CPI_IW
Error testing Inflation_AL → CPI_IW: grangercausalitytests() got an unexpected keyword argument 'verbose'

CPI_IW → Inflation_AL
Error testing CPI_IW → Inflation_AL: grangercausalitytests() got an unexpected keyword argument 'verbose'
NO significant Granger causality relationships found

Interpretation:
Granger causality means past values of X help predict current values of Y
This indicates predictive relationship, not necessarily true causation
```

## Cell 44 — Code

```python
irf = var_model.irf(periods=10)
irf_plot = irf.plot(orth=False, impulse='Inflation_AL', response='GDP_Growth')
plt.title('Impact of Inflation Shock on GDP Growth')
plt.show()
```

**Output**

![Output image 7](assets/output_cell_44_01_01.png)

```text
<Figure size 1000x1000 with 1 Axes>
```

## Cell 45 — Markdown

# VAR MODEL-FOR SEPARATE TIME PERIOD

## Cell 46 — Code

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('final_cleaned_economic_cpi_data.csv')
df['GDP_Growth'] = df['Gross Domestic Product'].pct_change() * 100
df['Inflation_AL'] = df['CPI_AL'].pct_change() * 100
df = df.dropna()
def assign_economic_era(year_str):
    year = int(year_str.split('_')[0])
    if year <= 1990:
        return "Pre-Liberalization"
    elif 1991 <= year <= 2007:
        return "Reform_Period"
    else:
        return "Modern_Era"

df['Economic_Era'] = df['Year'].apply(assign_economic_era)
print("ECONOMIC ERA DISTRIBUTION\n")
print(df['Economic_Era'].value_counts())
print("\nSample data:")
print(df[['Year', 'Economic_Era', 'GDP_Growth', 'Inflation_AL']].head(10))
plt.figure(figsize=(15, 5))
plt.subplot(1, 2, 1)
sns.scatterplot(data=df, x='Inflation_AL', y='GDP_Growth', hue='Economic_Era', style='Economic_Era', s=80)
plt.title('GDP Growth vs Inflation: Different Economic Eras')
plt.xlabel('Inflation Rate (%)')
plt.ylabel('GDP Growth Rate (%)')
plt.axhline(y=0, color='red', linestyle='--', alpha=0.3)
plt.axvline(x=0, color='red', linestyle='--', alpha=0.3)
plt.subplot(1, 2, 2)
for era in df['Economic_Era'].unique():
    era_data = df[df['Economic_Era'] == era]
    plt.plot(era_data['Year'], era_data['GDP_Growth'], marker='o', label=f'GDP Growth - {era}', linewidth=2)
    plt.plot(era_data['Year'], era_data['Inflation_AL'], marker='s', label=f'Inflation - {era}', linestyle='--', alpha=0.7)

plt.title('GDP Growth & Inflation Trends by Era')
plt.xlabel('Year')
plt.ylabel('Rate (%)')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()
print("\nERA-WISE STATISTICS\n")
era_summary = df.groupby('Economic_Era').agg({
    'GDP_Growth': ['mean', 'std', 'min', 'max'],
    'Inflation_AL': ['mean', 'std', 'min', 'max']
}).round(2)
print(era_summary)
```

**Output**

```text
ECONOMIC ERA DISTRIBUTION

Economic_Era
Pre-Liberalization    20
Reform_Period         17
Modern_Era            17
Name: count, dtype: int64

Sample data:
       Year        Economic_Era  GDP_Growth  Inflation_AL
1   1971_72  Pre-Liberalization    1.642910      1.030928
2   1972_73  Pre-Liberalization   -0.553327     10.714286
3   1973_74  Pre-Liberalization    3.295564     21.198157
4   1974_75  Pre-Liberalization    1.185285     34.600760
5   1975_76  Pre-Liberalization    9.149961     -3.954802
6   1976_77  Pre-Liberalization    1.663067    -13.823529
7   1977_78  Pre-Liberalization    7.254754     10.580205
8   1978_79  Pre-Liberalization    5.712550     -2.160494
9   1979_80  Pre-Liberalization   -5.238155      9.148265
10  1980_81  Pre-Liberalization    6.735812     14.161850
```

![Output image 8](assets/output_cell_46_02_01.png)

```text
<Figure size 1500x500 with 2 Axes>
```

```text

ERA-WISE STATISTICS

                   GDP_Growth                   Inflation_AL                \
                         mean   std   min   max         mean    std    min   
Economic_Era                                                                 
Modern_Era               6.15  3.54 -5.78  9.69         7.08   3.31   2.02   
Pre-Liberalization       4.33  3.45 -5.24  9.63         7.79   9.89 -13.82   
Reform_Period            6.12  2.12  1.06  8.85         1.39  21.87 -81.23   

                          
                     max  
Economic_Era              
Modern_Era          14.0  
Pre-Liberalization  34.6  
Reform_Period       19.3
```

## Cell 47 — Markdown

#FORECASTING-PREPARING FEATURES FOR FORECASTING

## Cell 48 — Code

```python
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error
import numpy as np
def create_forecasting_features(df, target_col='GDP_Growth', lags=3):
    features_df = df.copy()
    for lag in range(1, lags + 1):
        features_df[f'{target_col}_lag_{lag}'] = features_df[target_col].shift(lag)
        features_df[f'Inflation_AL_lag_{lag}'] = features_df['Inflation_AL'].shift(lag)
        features_df[f'CPI_IW_lag_{lag}'] = features_df['CPI_IW'].shift(lag)
    era_mapping = {'Pre-Liberalization': 0, 'Reform_Period': 1, 'Modern_Era': 2}
    features_df['Era_encoded'] = features_df['Economic_Era'].map(era_mapping)
    if 'GDP_Cycle' in features_df.columns:
        for lag in range(1, lags + 1):
            features_df[f'Cycle_lag_{lag}'] = features_df['GDP_Cycle'].shift(lag)
    features_df['target'] = features_df[target_col].shift(-1)

    return features_df.dropna()
forecast_df = create_forecasting_features(df)
print("Feature columns:", forecast_df.columns.tolist())
print("Dataset shape for forecasting:", forecast_df.shape)
```

**Output**

```text
Feature columns: ['Year', 'Gross Domestic Product', 'Net Domestic Product', 'Gross National Income', 'Per Capita GDP (₹)', 'Per Capita GNI (₹)', 'CPI_AL', 'CPI_IW', 'CPI_IW_Food', 'GDP_Growth', 'Inflation_AL', 'Economic_Era', 'GDP_Growth_lag_1', 'Inflation_AL_lag_1', 'CPI_IW_lag_1', 'GDP_Growth_lag_2', 'Inflation_AL_lag_2', 'CPI_IW_lag_2', 'GDP_Growth_lag_3', 'Inflation_AL_lag_3', 'CPI_IW_lag_3', 'Era_encoded', 'target']
Dataset shape for forecasting: (50, 23)
```

## Cell 49 — Markdown

# FORECASTING-TRAIN & TEST DATASET SPLIT

## Cell 50 — Code

```python
# Time-based split for train and test
split_year = 2010
train_mask = forecast_df['Year'].apply(lambda x: int(x.split('_')[0]) <= split_year)
test_mask = forecast_df['Year'].apply(lambda x: int(x.split('_')[0]) > split_year)

X_train = forecast_df[train_mask].drop(['Year', 'target', 'Economic_Era'], axis=1, errors='ignore')
X_test = forecast_df[test_mask].drop(['Year', 'target', 'Economic_Era'], axis=1, errors='ignore')
y_train = forecast_df[train_mask]['target']
y_test = forecast_df[test_mask]['target']

print(f"Train size: {X_train.shape[0]}, Test size: {X_test.shape[0]}")
print(f"Train years: {forecast_df[train_mask]['Year'].min()} to {forecast_df[train_mask]['Year'].max()}")
print(f"Test years: {forecast_df[test_mask]['Year'].min()} to {forecast_df[test_mask]['Year'].max()}")
```

**Output**

```text
Train size: 37, Test size: 13
Train years: 1974_75 to 2010_11
Test years: 2011_12 to 2023_24
```

## Cell 51 — Markdown

# FINDING THE BEST CORRELATION MODELS

## Cell 52 — Code

```python
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
models = {
    'Linear Regression': LinearRegression(),
    'XGBoost': XGBRegressor(n_estimators=100, random_state=42, learning_rate=0.1)
}

# Train and evaluate models
results = {}
predictions = {}

print("MODEL TRAINING RESULTS")
for name, model in models.items():
    # Train model
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    mae = mean_absolute_error(y_test, y_pred)
    mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100
    r2 = r2_score(y_test, y_pred)
    results[name] = {'RMSE': rmse, 'MAE': mae, 'MAPE': mape, 'R2': r2}
    predictions[name] = y_pred
    print(f"\n{name}:")
    print(f"  RMSE:  {rmse:.4f}")
    print(f"  MAE:   {mae:.4f}")
    print(f"  MAPE:  {mape:.2f}%")
    print(f"  R²:    {r2:.4f}")
baseline_pred = [X_test['GDP_Growth_lag_1'].iloc[i] for i in range(len(X_test))]
baseline_rmse = np.sqrt(mean_squared_error(y_test, baseline_pred))
baseline_mae = mean_absolute_error(y_test, baseline_pred)
baseline_mape = np.mean(np.abs((y_test - baseline_pred) / y_test)) * 100
baseline_r2 = r2_score(y_test, baseline_pred)
print(f"\nBASELINE (Last Value)")
print(f"RMSE:  {baseline_rmse:.4f}")
print(f"MAE:   {baseline_mae:.4f}")
print(f"MAPE:  {baseline_mape:.2f}%")
print(f"R²:    {baseline_r2:.4f}")
```

**Output**

```text
MODEL TRAINING RESULTS

Linear Regression:
  RMSE:  12.6339
  MAE:   10.4135
  MAPE:  163.45%
  R²:    -10.4034

XGBoost:
  RMSE:  4.1455
  MAE:   2.9200
  MAPE:  45.90%
  R²:    -0.2278

BASELINE (Last Value)
RMSE:  5.5129
MAE:   3.6595
MAPE:  55.52%
R²:    -1.1713
```

## Cell 53 — Code

```python
plt.figure(figsize=(15, 5))
plt.subplot(1, 2, 2)
xgb_model = models['XGBoost']
feature_importance_xgb = pd.DataFrame({
    'feature': X_train.columns,
    'importance': xgb_model.feature_importances_
}).sort_values('importance', ascending=True).tail(10)

plt.barh(feature_importance_xgb['feature'], feature_importance_xgb['importance'])
plt.title('XGBoost - Top 10 Feature Importance')
plt.xlabel('Importance')

plt.tight_layout()
plt.show()
```

**Output**

![Output image 9](assets/output_cell_53_01_01.png)

```text
<Figure size 1500x500 with 1 Axes>
```

## Cell 54 — Code

```python
improved_models = {
    'Linear Regression': LinearRegression(),
    'XGBoost (Improved)': XGBRegressor(
        n_estimators=150,
        max_depth=6,
        learning_rate=0.05,
        random_state=42
    ),
    'Baseline (Last Value)': 'baseline'
}
improved_results = {}
improved_predictions = {}

print("IMPROVED MODEL RESULTS")
for name, model in improved_models.items():
    if name == 'Baseline (Last Value)':
        improved_results[name] = {
            'RMSE': baseline_rmse,
            'MAE': baseline_mae,
            'MAPE': baseline_mape,
            'R2': baseline_r2
        }
        improved_predictions[name] = baseline_pred
    else:

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        mae = mean_absolute_error(y_test, y_pred)
        mape = np.mean(np.abs((y_test - y_pred) / y_test)) * 100
        r2 = r2_score(y_test, y_pred)

        improved_results[name] = {'RMSE': rmse, 'MAE': mae, 'MAPE': mape, 'R2': r2}
        improved_predictions[name] = y_pred

    print(f"\n{name}:")
    print(f"  RMSE:  {improved_results[name]['RMSE']:.4f}")
    print(f"  MAE:   {improved_results[name]['MAE']:.4f}")
    print(f"  MAPE:  {improved_results[name]['MAPE']:.2f}%")
    print(f"  R²:    {improved_results[name]['R2']:.4f}")


results_df = pd.DataFrame(improved_results).T
print("\nFINAL MODEL COMPARISON")
print(results_df.round(4))
```

**Output**

```text
IMPROVED MODEL RESULTS

Linear Regression:
  RMSE:  12.6339
  MAE:   10.4135
  MAPE:  163.45%
  R²:    -10.4034

XGBoost (Improved):
  RMSE:  4.1607
  MAE:   2.9341
  MAPE:  46.01%
  R²:    -0.2368

Baseline (Last Value):
  RMSE:  5.5129
  MAE:   3.6595
  MAPE:  55.52%
  R²:    -1.1713

FINAL MODEL COMPARISON
                          RMSE      MAE      MAPE       R2
Linear Regression      12.6339  10.4135  163.4481 -10.4034
XGBoost (Improved)      4.1607   2.9341   46.0105  -0.2368
Baseline (Last Value)   5.5129   3.6595   55.5235  -1.1713
```

## Cell 55 — Markdown

#XGBOOST

## Cell 56 — Code

```python

plt.figure(figsize=(15, 10))
plt.subplot(2, 1, 1)
years_test = [str(x) for x in range(2011, 2024)]  # 2011-2023

plt.plot(years_test, y_test.values, label='Actual GDP Growth', linewidth=3, marker='o')

for name, pred in improved_predictions.items():
    if name != 'Baseline (Last Value)':
        plt.plot(years_test, pred, label=f'{name} Predicted', marker='s', alpha=0.8)
    else:
        plt.plot(years_test, pred, label=f'{name}', marker='^', alpha=0.8)

plt.title('GDP Growth Forecasting: Actual vs Predicted (2011-2023)')
plt.ylabel('GDP Growth Rate (%)')
plt.xlabel('Year')
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
plt.grid(True, alpha=0.3)
plt.xticks(rotation=45)

plt.subplot(2, 1, 2)
best_model_name = results_df['RMSE'].idxmin()
best_predictions = improved_predictions[best_model_name]

plt.plot(years_test, y_test.values, label='Actual', linewidth=3, marker='o', color='blue')
plt.plot(years_test, best_predictions, label=f'{best_model_name} Predictions',
         linewidth=2, marker='s', color='red', linestyle='--')


error = np.abs(y_test.values - best_predictions)
plt.fill_between(years_test, best_predictions - error, best_predictions + error,
                 alpha=0.2, color='red', label='Prediction Error')

plt.title(f'Best Model: {best_model_name} - Forecast vs Actual')
plt.ylabel('GDP Growth Rate (%)')
plt.xlabel('Year')
plt.legend()
plt.grid(True, alpha=0.3)
plt.xticks(rotation=45)

plt.tight_layout()
plt.show()

print(f"\nBEST PERFORMING MODEL: {best_model_name}")
print(f"This model can be presented as your main forecasting approach")
```

**Output**

![Output image 10](assets/output_cell_56_01_01.png)

```text
<Figure size 1500x1000 with 2 Axes>
```

```text

BEST PERFORMING MODEL: XGBoost (Improved)
This model can be presented as your main forecasting approach
```

## Cell 57 — Markdown

# XG BOOST -TRAIN AND TEST RESULTS

## Cell 58 — Code

```python
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np

# Train XGBoost model on training data
xgb_model = XGBRegressor(
    n_estimators=150,
    max_depth=6,
    learning_rate=0.05,
    random_state=42
)

print("Training XGBoost model on training data...")
xgb_model.fit(X_train, y_train)

# Make predictions on training data
y_train_pred = xgb_model.predict(X_train)

# Make predictions on test data
y_test_pred = xgb_model.predict(X_test)

# Calculate metrics for training data
train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
train_mae = mean_absolute_error(y_train, y_train_pred)
train_mape = np.mean(np.abs((y_train - y_train_pred) / y_train)) * 100
train_r2 = r2_score(y_train, y_train_pred)

# Calculate metrics for test data
test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
test_mae = mean_absolute_error(y_test, y_test_pred)
test_mape = np.mean(np.abs((y_test - y_test_pred) / y_test)) * 100
test_r2 = r2_score(y_test, y_test_pred)

print("\nXGBOOST MODEL PERFORMANCE ANALYSIS\n")

print("\nTRAINING DATA PERFORMANCE (1974-2010):\n")
print(f"RMSE:  {train_rmse:.4f}")
print(f"MAE:   {train_mae:.4f}")
print(f"MAPE:  {train_mape:.2f}%")
print(f"R²:    {train_r2:.4f}")  # Use R² instead of R²

print("\nTEST DATA PERFORMANCE (2011-2023):\n")
print(f"RMSE:  {test_rmse:.4f}")
print(f"MAE:   {test_mae:.4f}")
print(f"MAPE:  {test_mape:.2f}%")
print(f"R²:    {test_r2:.4f}")  # Use R² instead of R²

print("\nPERFORMANCE ANALYSIS\n")
# Analyze overfitting
overfitting_rmse = train_rmse - test_rmse
overfitting_mae = train_mae - test_mae

print(f"\nOverfitting Analysis:\n")
print(f"RMSE difference (Train - Test): {overfitting_rmse:.4f}")
print(f"MAE difference (Train - Test): {overfitting_mae:.4f}")

if overfitting_rmse < 0:
    print("Model shows some overfitting (performs better on training data)")
else:
    print("Model generalizes well to test data")

# Accuracy interpretation
print(f"\nAccuracy Assessment:\n")
print(f"Training MAPE: {train_mape:.2f}% - This means the model is off by {train_mape:.2f}% on average on training data")
print(f"Test MAPE: {test_mape:.2f}% - This means the model is off by {test_mape:.2f}% on average on unseen data")

if test_mape < 20:
    print("Excellent forecasting accuracy")
elif test_mape < 40:
    print("Good forecasting accuracy")
elif test_mape < 60:
    print("Moderate forecasting accuracy")
else:
    print("Challenging forecasting task - typical for economic data")

# Precision interpretation
print(f"\nPrecision Assessment:")
print(f"Training RMSE: {train_rmse:.4f} - Average error magnitude on training data")
print(f"Test RMSE: {test_rmse:.4f} - Average error magnitude on test data")

# Compare with baseline (assuming baseline_rmse is defined)
baseline_rmse = 5.5129  # You may need to calculate this from your baseline model
baseline_improvement = ((baseline_rmse - test_rmse) / baseline_rmse) * 100
print(f"\nComparison with Baseline (Last Value method):")
print(f"XGBoost improves over baseline by: {baseline_improvement:.1f}% in RMSE")
```

**Output**

```text
Training XGBoost model on training data...

XGBOOST MODEL PERFORMANCE ANALYSIS


TRAINING DATA PERFORMANCE (1974-2010):

RMSE:  0.0517
MAE:   0.0300
MAPE:  0.75%
R²:    0.9996

TEST DATA PERFORMANCE (2011-2023):

RMSE:  4.1607
MAE:   2.9341
MAPE:  46.01%
R²:    -0.2368

PERFORMANCE ANALYSIS


Overfitting Analysis:

RMSE difference (Train - Test): -4.1090
MAE difference (Train - Test): -2.9041
Model shows some overfitting (performs better on training data)

Accuracy Assessment:

Training MAPE: 0.75% - This means the model is off by 0.75% on average on training data
Test MAPE: 46.01% - This means the model is off by 46.01% on average on unseen data
Moderate forecasting accuracy

Precision Assessment:
Training RMSE: 0.0517 - Average error magnitude on training data
Test RMSE: 4.1607 - Average error magnitude on test data

Comparison with Baseline (Last Value method):
XGBoost improves over baseline by: 24.5% in RMSE
```

## Cell 59 — Markdown

# COMPARISON WITH BASELINE MODEL AND XGBOOST

## Cell 60 — Code

```python
from xgboost import XGBRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np

# Train XGBoost model
xgb_model = XGBRegressor(
    n_estimators=150,
    max_depth=6,
    learning_rate=0.05,
    random_state=42
)

xgb_model.fit(X_train, y_train)
y_train_pred = xgb_model.predict(X_train)
y_test_pred = xgb_model.predict(X_test)

test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
test_mae = mean_absolute_error(y_test, y_test_pred)
test_mape = np.mean(np.abs((y_test - y_test_pred) / y_test)) * 100
test_r2 = r2_score(y_test, y_test_pred)

baseline_rmse = 5.5129
baseline_mae = 3.6595
baseline_mape = 55.52

# Calculate improvement percentages
rmse_improvement = ((baseline_rmse - test_rmse) / baseline_rmse) * 100
mae_improvement = ((baseline_mae - test_mae) / baseline_mae) * 100
mape_improvement = ((baseline_mape - test_mape) / baseline_mape) * 100

print("XGBoost Test Performance:")
print(f"RMSE: {test_rmse:.4f}")
print(f"MAE: {test_mae:.4f}")
print(f"MAPE: {test_mape:.2f}%")
print(f"R²: {test_r2:.4f}")

print("\nImprovement over Baseline:")
print(f"XGBoost reduces RMSE by {rmse_improvement:.1f}% compared to baseline")
print(f"XGBoost reduces MAE by {mae_improvement:.1f}% compared to baseline")
print(f"XGBoost reduces MAPE by {mape_improvement:.1f}% compared to baseline")

print("\nOverall, XGBoost shows moderate improvement over the baseline method for GDP growth forecasting.")
```

**Output**

```text
XGBoost Test Performance:
RMSE: 4.1607
MAE: 2.9341
MAPE: 46.01%
R²: -0.2368

Improvement over Baseline:
XGBoost reduces RMSE by 24.5% compared to baseline
XGBoost reduces MAE by 19.8% compared to baseline
XGBoost reduces MAPE by 17.1% compared to baseline

Overall, XGBoost shows moderate improvement over the baseline method for GDP growth forecasting.
```
